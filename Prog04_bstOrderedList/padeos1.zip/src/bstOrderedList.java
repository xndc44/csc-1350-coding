
public class bstOrderedList {

	class Node { 
		public Node leftChild;    
		public Comparable data;   
		public Node rightChild; 
	}
	private Node root;

	bstOrderedList () {
		
		root = null;
	}
	void add(Comparable newObject) {
		Node newNode = new Node();  
		newNode.data = newObject;  
		newNode.leftChild = null;  
		newNode.rightChild = null; 
		if (root == null) {
			root = newNode;
		}//if
		
		else {
			root.addNode(newNode);
		}//else

	}//insertion
	 
	void remove(Comparable newObject) {
		 Node tobeRemoved = root;
		 Node parent = null;
		 boolean found = false;
		 while (!found && tobeRemoved != null) {
			 int d = tobeRemoved.data.compareTo(newObject);
			 if (d == 0) { found = true; }
			 	
			 else {
				 parent = tobeRemoved;
				 if (d>0) {
					 tobeRemoved = tobeRemoved.leftChild;
				 }//if
				 else {
					 tobeRemoved = tobeRemoved.rightChild;
				 }//else
			 }//else
		 }//while
	}//remove
	
	int size() {
		
		return ;
	}//intsize
	
	boolean isEmpty() {
		
	}//isEmpty
	
	String toString() {
		
	}
	
}
