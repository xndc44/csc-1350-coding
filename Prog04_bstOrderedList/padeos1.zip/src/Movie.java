
public class Movie implements Comparable<Movie>{
	private String movieTitle;  
	private int releaseYear;  
	private String rating; 
	private int movieReview;

	public Movie (String Title, int Year, String rating, int Review) {
		
	}

	public String getTitle() {
		
		return movieTitle;
	}

	public int getYear() {
		
		return releaseYear;
	}
	
	public int getRating() {
		
		return rating;
	}//getRating
	
	public int getReview() {
		
		return movieReview;
	}//getReview
	
	public int compareTo(Movie other) {
		
		int CompareMovies = this.movie1.movieTitle.compareTo(other.movie2.movieTitle);

        if (CompareMovies != 0) {
            return CompareMovies;
        }//if
        else {
            if (this.movie1. releaseYear != other.movie2.releaseYear) {
                return this.movie1.releaseYear - other.movie2.releaseYear;
            }//if
            
            else {
                return 0;
            }//else
        }//else
	}//compareTo
	
	public String toString() {
		
		return String.format("Title: %s, Year: %s, Rating: %s Review: %s;", this.movieTitle, this.releaseYear, this.rating, this.movieReview);
	}
}
