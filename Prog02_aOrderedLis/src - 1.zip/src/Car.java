/**
 *
 * CSC 1351 Programming Project No 2
 * Section 02
 *
 * @author Patrick Adeosun
 * @since 2/19/2019
 */
public class Car implements Comparable<Car> {
    private String make;
    private int year;
    private int price;

    /**
     * Constructs a new car with the provided make, year, and price
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/19/2019
     */
    public Car(String make, int year, int price) {
        this.make = make;
        this.year = year;
        this.price = price;
    }

    /**
     * Gets the make for this car.
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/19/2019
     */
    public String getMake() {
        return make;
    }

    /**
     * Gets the year for this car.
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/19/2019
     */
    public int getYear() {
        return year;
    }

    /**
     * Gets the price for this car.
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/19/2019
     */
    public int getPrice() {
        return price;
    }

    /**
     * Compares this car with the provided car.
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/19/2019
     */
    public int compareTo(Car other) {
        int CompareCar = this.make.compareTo(other.make);

        if (CompareCar != 0) {
            return CompareCar;
        }
        else {
            if (this.year != other.year) {
                return this.year - other.year;
            } else {
                return 0;
            }
        }
    }

    /**
     * Returns a string representation of the car in the format Make, Year, Price
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/19/2019
     */
    public String toString() {
        return String.format("Make: %s, Year: %s, Price: %s;", this.make, this.year, this.price);
    }
}
