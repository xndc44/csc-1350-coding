

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.NumberFormat;
import java.util.Scanner;

/**
 * Main class that reads a file, puts the elements into a sorted list, and then writes the results to a file.
 *
 * CSC 1351 Programming Project No 2
 * Section 02
 *
 * @author Patrick Adeosun
 * @since 2/19/2019
 */
public class Prog02_aOrderedLis {
	
	
    /**
     * Opens the file located at the provided directory and returns a Scanner for that file.
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/19/2019
     */
	public static Scanner GetInputFile(String UserPrompt) throws FileNotFoundException {
		
		Scanner fileScanner = null;                       
		boolean	needInputFile = true;
		
		
        do {
            System.out.print(UserPrompt);
            Scanner LScanner = new Scanner(System.in);
            String fileName = LScanner.nextLine();
            System.out.println();
            
            try {
                fileScanner = new Scanner(new File(fileName));
                needInputFile = false;
            }//try
            
            catch (FileNotFoundException ex) {
                System.out.printf("File specified <%s> does not exist. Would you like to continue? <Y/N> ", fileName);
                if (LScanner.nextLine().toLowerCase().equals("n")) {
                    throw ex;
            }//if
                System.out.println();
            }//catch
        }//do
        
        while (needInputFile);
        
        return fileScanner;
	}//InputFile
	
    /**
     * Opens the file and returns PrintWriter to that file.
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/19/2019
     */
    public static PrintWriter GetOutputFile(String userPrompt) throws FileNotFoundException {

    	PrintWriter placefolder = null;                   
    	boolean	outFile = true;
        
       
        do {
            System.out.println("Enter output filename: ");
            Scanner in = new Scanner(System.in);
            String fileName = in.nextLine();
            System.out.println();
            try {
                placefolder = new PrintWriter(fileName);
                outFile = false;
            } //try
            catch (FileNotFoundException ex) {
                System.out.printf("File specified <%s> does not exist. Would you like to continue? <Y/N>", fileName);
                if (in.nextLine().toLowerCase().equals("n"))
                    throw ex;
                System.out.println();
            }//catch
            
        }//do
        
        while (outFile);
        
        return placefolder;
        
    }//GetOutputFile

    public static void main(String[] args) {

        Scanner fileScanner;                        
        PrintWriter placefolder;                     
        aOrderedList list = new aOrderedList();    
        
        
        
        try {
        	
        	fileScanner = GetInputFile("Enter input filename: ");

	        while(fileScanner.hasNextLine()) {
	            String[] elements = fileScanner.nextLine().split(",");
	            if (elements[0].equals("A")) {
	                list.add(new Car(elements[1], Integer.parseInt(elements[2]), Integer.parseInt(elements[3])));
	            }//if 
	            else if (elements[0].equals("D")) {
	                for(int i = 0; i < list.size(); i++) {
	                    Car element = (Car)list.get(i);
	                    if (element.getMake().equals(elements[1]) && element.getYear() == Integer.parseInt(elements[2])) {
	                        list.remove(i);
	                    }//if
	                }//for
	            }//else if
	        }//while
	
	        	      
	        placefolder = GetOutputFile("Enter output filename: ");
	
	        placefolder.append(String.format("Number of cars:%6s%n", list.size()));
	        for(int i = 0; i < list.size(); i++) {
	            Car item = (Car)list.get(i);
	            placefolder.append(String.format("%nMake:%12s%n", item.getMake()));
	            placefolder.append(String.format("Year:%12d%n", item.getYear()));
	
	
	            NumberFormat formatter = NumberFormat.getCurrencyInstance();
	            String priceString = formatter.format(item.getPrice());
	            placefolder.append(String.format("Price:%11s%n%n", priceString.substring(0, priceString.length() - 3)));
	        }
	        placefolder.close();
	    }//try
	    catch (FileNotFoundException ex) {
	    	System.out.println("User terminated program");
	    }//catch


    }//main


}//Prog02_aOrderedList class

