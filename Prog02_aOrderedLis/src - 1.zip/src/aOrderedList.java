import java.util.Arrays;

/**
 *
 * CSC 1351 Programming Project No 2
 * Section 02
 *
 * @author Patrick Adeosun
 * @since 2/19/2019
 */
public class aOrderedList {

    final int SIZEINCRMENTS = 20;   // Size of increments for increasing ordered list

    private Comparable[] List;            // The ordered list
    private int listSize;           // The size of the ordered list
    private int numObjects;         // The number of objects in the ordered list

    private int curr;


    /**
     * Creates an ordered list
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/19/2019
     */
    public aOrderedList() {
        numObjects = 0;
        listSize = SIZEINCRMENTS;
        List = new Comparable[SIZEINCRMENTS];
    }//public

    /**
     * Adds a new element into the list
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/19/2019
     */
    public void add(Comparable newObject) {

        if (numObjects >= listSize) {
            List = Arrays.copyOf(List, List.length + SIZEINCRMENTS);
        }//if

        if (isEmpty())
        {
            List[0] = newObject;
        }//if
        else {
            for (int i = 0; i < numObjects + 1; i++) {
                if (List[i] == null) {
                    List[i] = newObject;
                }//if
                else {
                    int result = List[i].compareTo(newObject);
                    if (result > 0) {
                        Comparable nextObject = newObject;
                        for (int j = i; j <= numObjects; j++) {
                            Comparable tmp = List[j];
                            List[j] = nextObject;
                            nextObject = tmp;
                        }//for
                        break;
                    }//if
                }//else
            }//for
        }//else


        numObjects++;
    }//comparable

    /**
     * Returns a string representation of the list object.
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/19/2019
     */
    public String toString() {
        StringBuilder StringBuilder = new StringBuilder();

        if (numObjects > 0) {
            for (int i = 1; i < numObjects; i++) {
                StringBuilder.append(String.format("[%s]%n", List[i].toString()));
            }//for
        }//if

        return StringBuilder.toString();
    }//toString

    /**
     * Returns the number of elements in the list.
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/19/2019
     */
    public int size() {
        return numObjects;
    }//size

    /**
     * Gets the element at the provided index
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/19/2019
     */

    /**
     * Returns true when the list is empty
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/19/2019
     */
    public boolean isEmpty() {
        return numObjects == 0;
    }//Empty

    /**
     * Removes elements and reorders the array
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/19/2019
     */


    /**
     * Resets the iterator to the first element.
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/25/19
     */
    public void reset() { 
    	curr = 0; 
    }//reset

    /**
     * Returns the next element in the array and increments the iterator.
     *
     * CSC 1351 Programming Project No 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/25/19
     */
    public Comparable next() {
        Comparable item = List[curr + 1];
        curr++;
        return item;
    }//comparable

    /**
     * Returns true if the next object in List is not null.
     *
     * CSC 1351 Programming Project 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/25/19
     */
    public boolean hasNext() { 
    	return List[curr + 1] != null; 
    }//hasNext

    /**
     * Removes the last item in the array.
     *
     * CSC 1351 Programming Project 2
     * Section 02
     *
     * @author Patrick Adeosun
     * @since 2/25/19
     */
    public void remove() {
        reset();
        while(hasNext())
        {
            next();
        }//while
        List[curr] = null;
        reset();
    }//remove
}//aOrderedList
