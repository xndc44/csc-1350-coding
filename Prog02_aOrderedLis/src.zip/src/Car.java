/** 
 * <Method description>
 * 
 * CSC 1351 Programming Project No <enter project number here> 
 * Section <Section 2>
 * 
 * @author <Patrick Adeosun> 
 * @since <2/25/19>
 */
import java.util.Scanner;
public class Car {
	
	private String make;  
	private int year;  
	private int price;
	
	/** 
	 * <Method description>
	 * 
	 * CSC 1351 Programming Project No <enter project number here> 
	 * Section <Section 2>
	 * 
	 * @author <Patrick Adeosun> 
	 * @since <2/25/19>
	 */	
	public Car(String m, int y, int p) {
		 
		make =  m;
		year = y;
		price = p;	
	}
	/** 
	 * <Method description>
	 * 
	 * CSC 1351 Programming Project No <enter project number here> 
	 * Section <Section 2>
	 * 
	 * @author <Patrick Adeosun> 
	 * @since <2/25/19>
	 */
    public void setYearModel(int y){
        year = y;
    }
    /** 
     * <Method description>
     * 
     * CSC 1351 Programming Project No <enter project number here> 
     * Section <Section 2>
     * 
     * @author <Patrick Adeosun> 
     * @since <2/25/19>
     */
    public void setMake(String type){
        make = type;
    }
    /** 
     * <Method description>
     * 
     * CSC 1351 Programming Project No <enter project number here> 
     * Section <Section 2>
     * 
     * @author <Patrick Adeosun> 
     * @since <2/25/19>
     */
    
	public String getMake() {
	
	return make;
	}
	/** 
	 * <Method description>
	 * 
	 * CSC 1351 Programming Project No <enter project number here> 
	 * Section <Section 2>
	 * 
	 * @author <Patrick Adeosun> 
	 * @since <2/25/19>
	 */
	public int getYear() {
		
	return year;	
	}
	/** 
	 * <Method description>
	 * 
	 * CSC 1351 Programming Project No <enter project number here> 
	 * Section <Section 2>
	 * 
	 * @author <Patrick Adeosun> 
	 * @since <2/25/19>
	 */
	public int compareTo(Car other) {
		
			
		
		String a = "";
		return year;
	}
	public String toString() {
		return  String.format("Make: "  + make + ", Year : " + year + ", Price: " + price);
	}
}
