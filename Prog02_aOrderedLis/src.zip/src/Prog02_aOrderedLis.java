/** 
 * <Receives the variable the user sends>
 * 
 * CSC 1351 Programming Project No <enter project number here> 
 * Section <Section 2>
 * 
 * @author <Patrick Adeosun> 
 * @since <2/25/19>
 */

import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import javax.swing.JFileChooser;
import java.io.FileReader;
import java.io.BufferedReader;

public class Prog02_aOrderedLis {
static String text = "";
	public static void main(String[] args) throws FileNotFoundException {
		Scanner in = new Scanner(System.in);
		String UserPrompt;
		try {
			Car[] car = new Car[0];
			System.out.print("Enter file name: ");
			UserPrompt = in.nextLine();
			in = new Scanner (new File(UserPrompt));
			UserPrompt = new String(Files.readAllBytes(Paths.get(UserPrompt)));
			in.useDelimiter(",|\n");
			
			String make = in.next();
			int year = in.nextInt();
			int price = in.nextInt();
			
			Car newCar = new Car(make, year, price);
	        car = addCar(car, newCar);

	    for (Car Car : car) {
	        System.out.println(Car);
	    }

			in.close();
			
			
		
		}// try
		catch (FileNotFoundException exception) 
		{
			exception.printStackTrace();
			System.out.print("File Not Found!");
		}//catch file
		catch (IOException e) {
			      e.printStackTrace();
		}// catch io
		catch(Exception e){
            System.err.println("Error: " + e.getMessage());
            System.out.print("Would you like to continue? (Y/N)");
            String Error = in.nextLine();

		}//catch e
}
	/** 
	 * <Gets the file name from user>
	 * 
	 * CSC 1351 Programming Project No <enter project number here> 
	 * Section <Section 2>
	 * 
	 * @author <Patrick Adeosun> 
	 * @since <2/25/19>
	 */
	public static Scanner GetInputFile(String UserPrompt) throws FileNotFoundException {
		
		Scanner in = new Scanner(System.in);
		System.out.print("Enter file name: ");
		UserPrompt = in.nextLine();

		return in;
	}	
	/** 
	 * <Stores data in array>
	 * 
	 * CSC 1351 Programming Project No <enter project number here> 
	 * Section <Section 2>
	 * 
	 * @author <Patrick Adeosun> 
	 * @since <2/25/19>
	 */
	
	private static Car[] addCar(Car[] car, Car carToAdd) {
	    Car[] newCar = new Car[car.length + 1];
	    System.arraycopy(car, 0, newCar, 0, car.length);
	    newCar[newCar.length - 1] = carToAdd;

	    return newCar;
	}

}


