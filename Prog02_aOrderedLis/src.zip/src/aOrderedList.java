/** 
 * <Method description>
 * 
 * CSC 1351 Programming Project No <enter project number here> 
 * Section <Section 2>
 * 
 * @author <Patrick Adeosun> 
 * @since <2/25/19>
 */
/** 
 * <Method description>
 * 
 * CSC 1351 Programming Project No <enter project number here> 
 * Section <Section 2>
 * 
 * @author <Patrick Adeosun> 
 * @since <2/25/19>
 */
public class aOrderedList {
	final int SIZEINCREMENTS = 20;
	private Car[] oList;
	private int listSize; 
	private int numObjects; 
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	/** 
	 * <Stores data in array>
	 * 
	 * CSC 1351 Programming Project No <enter project number here> 
	 * Section <Section 2>
	 * 
	 * @author <Patrick Adeosun> 
	 * @since <2/25/19>
	 */
	public aOrderedList(String a) {
		String b  = a;
	}
	/** 
	 * <Method description>
	 * 
	 * CSC 1351 Programming Project No <enter project number here> 
	 * Section <Section 2>
	 * 
	 * @author <Patrick Adeosun> 
	 * @since <2/25/19>
	 */	
	void add(Car newCar) {
		
	}
	/** 
	 * <Method description>
	 * 
	 * CSC 1351 Programming Project No <enter project number here> 
	 * Section <Section 2>
	 * 
	 * @author <Patrick Adeosun> 
	 * @since <2/25/19>
	 */	
	public String toString() {
		return null;
		
	}

}
